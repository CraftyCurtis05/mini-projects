package com.example.PlantsApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantsApplicationTests {

	@Test
	void contextLoads() {
	}

}
